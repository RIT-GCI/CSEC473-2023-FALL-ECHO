import asyncio
import atexit
import threading
from flask import Flask, request, jsonify, render_template #communication
from ftplib import FTP, error_perm #ftp
from rocketchat_API.rocketchat import RocketChat
import rocketchat_API #rocketchat
import mysql.connector #mysql
import httpx #http
import pandas #edit csvfiles
from datetime import datetime


app = Flask(__name__)

#store scores locally
blue_team_score = 0
red_team_score = 0

#hold passwords for score engine
SCORE_PASSWORD = 'gameover'
REDACCESS = 'TomTheCat'

flaskServer = 'http://127.0.0.1:5000'
service_lock = asyncio.Lock()

#keep filenames 
scores_file = "scores.csv"
services_file = "services.csv"
tj_file = "tj.csv"
log_file = "log.txt"

#host: service running on it
hosts_services = {
    '192.168.10.102': 'http',
    '192.168.10.132': 'http',
    '192.168.10.78': 'ftp',
    '192.168.10.229': 'RocketChat',
    '192.168.10.246': 'sql'
    # Add other IP: services as needed
}

# updates the score csv with the current scores
# this enables me to stop the program and pick up where I left off
def update_score_file():
    scoref = pandas.read_csv(scores_file)
    scoref["bluescore"] = blue_team_score
    scoref["redscore"] = red_team_score
    scoref.to_csv(scores_file, index=False)
    append_log_file("Score File Updated: bluescore=" + str(blue_team_score) + " redscore=" + str(red_team_score))

#log a message 
def append_log_file(message):
    logf = open(log_file, 'a')
    dt = datetime.now()
    strDT = dt.strftime("%d-%m-%Y, %H:%M:%S")
    logf.write("[" + strDT + "] " + message + "\n")
    logf.close()

#gets the scores from the file 
def get_saved_scores():
    append_log_file("Updating global vars...")
    global blue_team_score, red_team_score
    scoref = pandas.read_csv(scores_file)
    blue_team_score = int(scoref["bluescore"].iloc[0])
    red_team_score = int(scoref["redscore"].iloc[0])
    append_log_file("Updated global score variables: bluescore=" + str(blue_team_score) + ", redscore=" + str(red_team_score))

#ensures the scores are pulled from the file and not reset to 0 because of the global vars above on refresh or startup
get_saved_scores()


#allows refresh and init start up 
@app.route('/', methods=['GET'])
def startup():
    append_log_file("render html")
    return render_template('index.html')


#initializes the table with the services so it doesnt take the refresh period on the initial load 
@app.route('/populate_table', methods=['GET'])
def get_saved_status():
    append_log_file('populating table data...')
    status = {}
    servicef = pandas.read_csv(services_file)
    for index, row in servicef.iterrows():
        status[row["ip"]] = {
            "serviceName": row["service"],
            "status": row["status"]
        }
    append_log_file('table data aquired.')
    return jsonify(status)

#communicates the scores to the front end 
@app.route('/get_scores', methods=['GET'])
def get_scores():
    append_log_file("Get scores: bluescore=" + str(blue_team_score) + ", redscore=" + str(red_team_score))
    return jsonify({'blue_team': str(blue_team_score), 'red_team': str(red_team_score)})

#allows grey team to add a number of points to either team's score 
@app.route('/add_score', methods=['POST'])
def add_score():
    global blue_team_score, red_team_score
    team = request.json.get('team')
    points = request.json.get('points')
    password = request.json.get('password')
    append_log_file('attempting to add ' + str(points) + ' points to ' + team + " team using password:" + password + "...")
    if password == SCORE_PASSWORD:
        append_log_file('password accepted...')
        if team == 'blue':
            blue_team_score += points
        elif team == 'red':
            red_team_score += points
        append_log_file('GreyTeam added ' + str(points) + ' points to ' + team)
        msg = 'Added ' + str(points) + ' points to ' + team
    else:
        msg = 'password not accepted'
    update_score_file()
    append_log_file("Add score: " + msg + " -> bluescore=" + str(blue_team_score) + ", redscore=" + str(red_team_score))
    return jsonify({'message': msg})

#red team submits the "cheese" for points 
@app.route('/submit_pass', methods=['POST'])
def subPass():
    
    global red_team_score
    password = request.json.get('password')
    redAccess = request.json.get('redAccess')
    append_log_file("Attempting password submission with password: " + password + ' and access code: ' + redAccess + '...')
    if redAccess == REDACCESS:
        append_log_file("access code accepted: redteam permitted to submit password")
        tjf = pandas.read_csv(tj_file)

        if password in tjf['pword'].tolist():
            points = tjf.loc[tjf['pword'] == password, 'value'].iloc[0]  
 
            if(points == 0):
                msg = 'password already submitted<br>' + str(points) + ' points added'
            else:
                red_team_score += points
                tjf.loc[tjf['pword'] == password, 'value'] = 0
                tjf.to_csv(tj_file, index=False)
                msg = 'password accepted<br>' + str(points) + ' points added!'
            append_log_file("Password Accepted: updated_redscore=" + str(red_team_score) + " pointsAwarded=" + str(points) + " for password=" + password)
        else:
            red_team_score -= 1
            msg = 'password incorrect<br>1 point deducted :('
            append_log_file("Password Failed: updated_redscore=" + str(red_team_score) + " (one point deducted)" + " for passwordAttempt=" + password)
        update_score_file()
    else:
        append_log_file("Access Code: " + redAccess + " incorrect")
        msg = 'incorrect access code :( <br> try again'
    return jsonify({'message': msg})


async def start_services_check():
    while True:
        
        now = datetime.now()
        if now.minute % 3 == 0:
            await get_services_status()
            # Sleep for a while to avoid multiple executions within the same minute
            await asyncio.sleep(60)  
        else:
            # Sleep for a shorter period, then check the time again
            await asyncio.sleep(10)
            

#gets whether the services are active 
@app.route('/get_services_status', methods=['GET'])
async def get_services_status():
    append_log_file("getting services status...")
    status = await asyncio.gather(
        *(check_service_status(ip, service) for ip, service in hosts_services.items())
    )
    update_score_file()
    update_service_file(status)


def update_service_file(status_data):
    servicef = pandas.read_csv(services_file)
    for item in status_data:
        ip = item[0]
        status = item[1]["status"]
        servicef.loc[servicef["ip"] == ip, "status"] = status
        append_log_file('service db updated for host: ' + ip + ' with status ' + str(status))
    servicef.to_csv(services_file, index=False)

#checks if the status is running or not 
async def check_service_status(ip, service):
    append_log_file("checking service: " + service + " on host: " + ip + '...')
    global blue_team_score, red_team_score
    is_running = await is_service_running(ip, service)
    if is_running:
        blue_team_score += 1
    else: 
        red_team_score += 1
    return ip, {
        "serviceName": service,
        "status": is_running
    }


# pulls which service you are checking and sees if that specific service is running on the host 
async def is_service_running(ip, service):
    match service:
        case 'http':
            return await is_http_running_async(ip)
        case 'RocketChat':
            return await is_rocket_running_async(ip)
        case 'ftp':
            return await is_ftp_running_async(ip)
        case 'sql':
            return await is_sql_running_async(ip)
        case _ :
            return True #TODO error catching 
        

#connects to http web server to confirm it is running 
async def is_http_running_async(ip):
    async with httpx.AsyncClient() as client:
        try:
            res = await client.get('http://' + ip, timeout=2)
            return res.status_code == 200
        except:
            return False
    

#connects to rocketchat asynchronously
async def is_rocket_running_async(ip):
    loop = asyncio.get_event_loop()
    try:
        result = await loop.run_in_executor(None, is_rocket_running, ip)  # None means default executor (i.e., a ThreadPoolExecutor)
        return result
    except Exception as e:
        print(e)
        return False


#checks rocket chat service by connecting using the user GreyAdmin
def is_rocket_running(ip):
    try:
        rocket = RocketChat('GreyAdmin', 'GreyAdmin1!', server_url='http://'+ ip)
        return True
    except rocketchat_API.APIExceptions.RocketExceptions.RocketAuthenticationException:
        return True
    except Exception as e:
        return False
    

# connects to ftp asynchronously
async def is_ftp_running_async(ip):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, is_ftp_running, ip)  # None means default executor (i.e., a ThreadPoolExecutor)
    return result


#uses anon login to connect to ftp and confirm the service is running
def is_ftp_running(ip):
    try:
        ftp = FTP(ip)
        ftp.login()
        ftp.quit()
        return True
    except error_perm:
        return True
    except:
        return False


#connects to sql server asynchronously
async def is_sql_running_async(ip):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, is_sql_running, ip)
    return result


#checks sql service is running by connecting with the user 
def is_sql_running(ip):
    try:
        mysql.connector.connect(user='greyAdmin2', password='sqlGrey', host=ip)
        return True
    except:
        return False


def run_asyncio_loop():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(start_services_check())
    loop.close()

if __name__ == "__main__":
    threading.Thread(target=run_asyncio_loop, daemon=True).start()
    app.run(debug=True, host='0.0.0.0')
    #app.run(debug=True, host='0.0.0.0') => this line runs it on the ip instead of the loopback address 
    #The second line is used on the server 
