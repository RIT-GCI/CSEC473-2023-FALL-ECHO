from datetime import datetime
import pandas
import shutil
from tj import cheese as CHEESE

scores_file = "scores.csv"
services_file = "services.csv"
tj_file = "tj.csv"
log_file = "log.txt"
report_file = "_report.txt"

blueBonusPoints = 0;

def createReport(red, blue, flagsfound, flagsleft):
    with open('reports/' + datetime.now().strftime("%d%m%Y_%H%M%S") + report_file, 'w') as file:
        file.write('Tom and Jerry Comp Report\n\n')
        file.write('Blue Score: ' + str(blue) + '\tRedScore: ' + str(red))
        file.write('\n\n[Flags Found]\n')
        for line in flagsfound:
            file.writelines(line + '\n')
        file.write('\n\n[Flags Left]\n')
        for line in flagsleft:
            file.writelines(line + '\n')
    file.close()

def resetScoresFile():
    scoref = pandas.read_csv(scores_file)
    blue_team_score = int(scoref["bluescore"].iloc[0])
    red_team_score = int(scoref["redscore"].iloc[0])
    scoref['bluescore'] = 0
    scoref['redscore'] = 0
    scoref.to_csv(scores_file, index=False)
    return (blue_team_score, red_team_score)


def resetServicesFile():
    servicef = pandas.read_csv(services_file)
    servicef['status'] = True
    servicef.to_csv(services_file, index=False)


def resetTjFile():
    global blueBonusPoints
    passwordsFound = [] 
    passwordsLeft = []
    tjf = pandas.read_csv(tj_file)
    for p in CHEESE.keys():
        points = tjf.loc[tjf['pword'] == p, 'value'].iloc[0] 
        if points == 0:
            passwordsFound.append(p) 
        else: 
            passwordsLeft.append(p)
            blueBonusPoints += points 
        tjf.loc[tjf['pword'] == p, 'value'] = CHEESE[p] 
    tjf.to_csv(tj_file, index=False)
    return (passwordsFound, passwordsLeft)


def main():
    shutil.move(log_file, 'logs/'+ datetime.now().strftime("%d%m%Y_%H%M%S") + '.txt')
    blue, red = resetScoresFile()
    resetServicesFile()
    flagsFound, flagsLeft = resetTjFile()
    createReport(red, blue+blueBonusPoints, flagsFound, flagsLeft)
    with open('log.txt', 'a'):
        pass


if __name__ == "__main__":
    main()