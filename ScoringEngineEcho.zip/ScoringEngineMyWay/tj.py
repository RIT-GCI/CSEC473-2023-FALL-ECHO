cheese = {
    'Blu3_T3am1!': 5, #linux1
    'Red_T34m123!': 5, #linux1
    'Gray_T3Am_R0Ck5!!': 5,#linux1
    'Blue_TEEM_Pa55wd_2023!': 5,#linux1
    'Red_Pa55w0rD_23!': 5,#linux1
    'Blue_Team_Blue_Pa55word!d': 5,#linux2
    'Red_TeAm123454321!': 5,#linux2
    'Gray_Grey_Team_pswd1!': 5,#linux2
    'Redsec_four_seven_three473!': 5,#linux2
    'Red_BLUE_gray_team32123!': 5,#linux2
    'CheeselsLife2023!': 5, #Windows1
    'P4ssw@rd12!': 5, #Windows1
    'H4ckme4fun': 5,#Windows1
    'M0ney': 5,#Windows1
    'BlockTh3mOut!!': 5,#Windows1
    'Y0ullN3verF1ndMe!': 5,#Windows2
    '!Ch33se': 5,#Windows2
    'A_B_C_D_3!': 5,#Windows2
    'G0tIn': 5,#Windows2
    'P4ssw@rds42!!': 5,#Windows2
    '2023-2024_UP100%': 5,#Windows3
    'NeverCatchJerry!': 5,#Windows3
    '192168101': 5,#Windows3
    'Can_CatchJ3rry!2': 5,#Windows3
    'FlyyyyAw4y!!': 5,#Windows3
    'whiteout': 10, #white text 
    'comment_secret_code': 10, #comment in css  
    'table_sql_pass': 15, #sql flag 
    'We_out_here': 15, #sql flag 
    'munster_gouda_provolone_feta': 10,#ftp
    'parmesan_queso_colby_brie': 10, #ftp
    'ricotta_cottage_roquefort_pecorino': 10 #ftp
}