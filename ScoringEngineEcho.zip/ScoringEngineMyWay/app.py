import asyncio
from flask import Flask, request, jsonify, render_template #communication
from time import sleep
from ftplib import FTP, error_perm #ftp
from rocketchat_API.rocketchat import RocketChat
import rocketchat_API #rocketchat
import pyodbc #sql
import httpx #http
import pandas #edit csvfiles
import datetime;

app = Flask(__name__)

blue_team_score = 0
red_team_score = 0

SCORE_PASSWORD = 'gameover'
REDACCESS = 'TomTheCat'

flaskServer = 'http://127.0.0.1:5000'
service_lock = asyncio.Lock()

scores_file = "scores.csv"
services_file = "services.csv"
tj_file = "tj.csv"
log_file = "log.txt"


hosts_services = {
    '192.168.10.102': 'http',
    '192.168.10.132': 'http',
    '192.168.10.78': 'ftp',
    '192.168.10.229': 'RocketChat',
    '192.168.10.246': 'sql'
    # Add other IP: services as needed
}

def update_score_file():
    scoref = pandas.read_csv(scores_file)
    scoref["bluescore"] = blue_team_score
    scoref["redscore"] = red_team_score
    scoref.to_csv(scores_file, index=False)
    append_log_file("Score File Updated: bluescore=" + str(blue_team_score) + " redscore=" + str(red_team_score))


def append_log_file(message):
    logf = open(log_file, 'a')
    dt = datetime.datetime.now()
    strDT = dt.strftime("%d-%m-%Y, %H:%M:%S")
    logf.write("[" + strDT + "] " + message + "\n")
    logf.close()


def get_saved_scores():
    append_log_file("Updating global vars...")
    global blue_team_score, red_team_score
    scoref = pandas.read_csv(scores_file)
    blue_team_score = int(scoref["bluescore"].iloc[0])
    red_team_score = int(scoref["redscore"].iloc[0])
    append_log_file("Updated global score variables: bluescore=" + str(blue_team_score) + ", redscore=" + str(red_team_score))


get_saved_scores()


@app.route('/', methods=['GET'])
def startup():
    append_log_file("render html")
    return render_template('index.html')


@app.route('/init_table', methods=['GET'])
def get_saved_status():
    append_log_file('initializing table data...')
    status = {}
    servicef = pandas.read_csv(services_file)
    for index, row in servicef.iterrows():
        status[row["ip"]] = {
            "serviceName": row["service"],
            "status": row["status"]
        }
    append_log_file('table data aquired.')
    return jsonify(status)


@app.route('/get_scores', methods=['GET'])
def get_scores():
    append_log_file("Get scores: bluescore=" + str(blue_team_score) + ", redscore=" + str(red_team_score))
    return jsonify({'blue_team': str(blue_team_score), 'red_team': str(red_team_score)})


@app.route('/add_score', methods=['POST'])
def add_score():
    global blue_team_score, red_team_score
    team = request.json.get('team')
    points = request.json.get('points')
    password = request.json.get('password')
    append_log_file('attempting to add ' + str(points) + ' points to ' + team + " team using password:" + password + "...")
    if password == SCORE_PASSWORD:
        append_log_file('password accepted...')
        if team == 'blue':
            blue_team_score += points
            append_log_file('added ' + points + ' points to ' + team)
        elif team == 'red':
            red_team_score += points
            append_log_file('added ' + points + ' points to ' + team)
        msg = 'Score updated!'
    else:
        msg = 'password not accepted'
    update_score_file()
    append_log_file("Add score: " + msg + " -> bluescore=" + str(blue_team_score) + ", redscore=" + str(red_team_score))
    return jsonify({'message': msg})


@app.route('/submit_pass', methods=['POST'])
def subPass():
    
    global red_team_score
    password = request.json.get('password')
    redAccess = request.json.get('redAccess')
    append_log_file("Attempting password submission with password: " + password + ' and access code: ' + redAccess + '...')
    if redAccess == REDACCESS:
        append_log_file("access code accepted: redteam permitted to submit password")
        tjf = pandas.read_csv(tj_file)

        if password in tjf['pword'].tolist():
            points = tjf.loc[tjf['pword'] == password, 'value'].iloc[0]  
 
            if(points == 0):
                msg = 'password already submitted<br>' + str(points) + ' points added'
            else:
                red_team_score += points
                tjf.loc[tjf['pword'] == password, 'value'] = 0
                tjf.to_csv(tj_file, index=False)
                msg = 'password accepted<br>' + str(points) + ' points added!'
            append_log_file("Password Accepted: updated_redscore=" + str(red_team_score) + " pointsAwarded=" + str(points) + " for password=" + password)
        else:
            red_team_score -= 1
            msg = 'password incorrect<br>1 point deducted :('
            append_log_file("Password Failed: updated_redscore=" + str(red_team_score) + " (one point deducted)" + " for passwordAttempt=" + password)
        update_score_file()
    else:
        append_log_file("Access Code: " + redAccess + " incorrect")
        msg = 'incorrect access code'
    return jsonify({'message': msg})


@app.route('/get_services_status', methods=['GET'])
async def get_services_status():
    append_log_file("getting services status...")
    status = await asyncio.gather(
        *(check_service_status(ip, service) for ip, service in hosts_services.items())
    )
    return jsonify(dict(status))

async def check_service_status(ip, service):
    append_log_file("checking service: " + service + " on host: " + ip + '...')
    global blue_team_score, red_team_score
    is_running = await is_service_running(ip, service)
    if is_running:
        blue_team_score += 1
    else: 
        red_team_score += 1
    update_score_file();
    async with service_lock:
        servicef = pandas.read_csv(services_file)
        servicef.loc[servicef["ip"] == ip, "status"] = is_running
        servicef.to_csv(services_file, index=False)
        append_log_file('service db updated for host: ' + ip + ' with status ' + str(is_running))
    return ip, {
        "serviceName": service,
        "status": is_running
    }



async def is_service_running(ip, service):
    match service:
        case 'http':
            return await is_http_running_async(ip)
        case 'RocketChat':
            return await is_rocket_running_async(ip)
        case 'ftp':
            return await is_ftp_running_async(ip)
        case 'sql':
            return await is_sql_running_async(ip)
        case _ :
            return True #TODO error catching 
        

async def is_http_running_async(ip):
    async with httpx.AsyncClient() as client:
        try:
            res = await client.get('http://' + ip, timeout=2)
            return res.status_code == 200
        except:
            return False
    

async def is_rocket_running_async(ip):
    loop = asyncio.get_event_loop()
    try:
        result = await loop.run_in_executor(None, is_rocket_running, ip)  # None means default executor (i.e., a ThreadPoolExecutor)
        return result
    except Exception as e:
        print(e)
        return False

def is_rocket_running(ip):
    try:
        rocket = RocketChat('GreyAdmin', 'GreyAdmin1!', server_url='http://'+ ip)
        return True
    except rocketchat_API.APIExceptions.RocketExceptions.RocketAuthenticationException:
        return True
    except Exception as e:
        return False
    

async def is_ftp_running_async(ip):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, is_ftp_running, ip)  # None means default executor (i.e., a ThreadPoolExecutor)
    return result

def is_ftp_running(ip):
    try:
        ftp = FTP(ip)
        ftp.login()
        ftp.quit()
        return True
    except error_perm:
        return True
    except:
        return False


async def is_sql_running_async(ip):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, is_sql_running, ip)
    return result

def is_sql_running(ip):
    try:
        pyodbc.connect('Driver{SQL Server};'
                       f'Server={ip};'
                       f'Database=localhost;'
                       'Trusted_Connection=yes;'
                       'Timeout=2;')
        return True
    except:
        return False





if __name__ == "__main__":
    app.run(debug=True)
